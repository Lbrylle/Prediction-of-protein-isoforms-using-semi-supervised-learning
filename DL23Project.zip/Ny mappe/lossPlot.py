import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt

def createLossPlot(training_loss, validation_loss, epoch):
    print("T-loss", training_loss)
    plt.figure(figsize=(10, 5))
    plt.title(r'Loss')
    plt.plot(training_loss, label='Training')
    plt.plot(validation_loss, label='Validation')
    plt.legend()
    plt.tight_layout()
    tmp_img = 'loss.png'
    plt.savefig(tmp_img)

def createELBOPlot(training_data, validation_data, epoch):
    #ax = axarr[0, 0]
    # plot ELBO
    # ax = axes[1, 0]
    
    plt.figure(figsize=(10, 5))
    plt.title(r'ELBO: $\mathcal{L} ( \mathbf{x} )$')
    plt.plot(training_data['elbo'], label='Training')
    plt.plot(validation_data['elbo'], label='Validation')
    plt.legend()
    plt.tight_layout()
    tmp_img = 'elbo.png'
    plt.savefig(tmp_img)
    #plt.close(fig)
    #display(Image(filename=tmp_img))
    #clear_output(wait=True)
    #os.remove(tmp_img)
    
    